<?php

namespace App\Http\Controllers;
use App\Models\freetimes_time;
use App\Models\Expert;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    //validate
    public function CreateAppointment(Request $request)
    {
        //Days maean these day expert Avilable

        $request->validate([
            'Days_u_Avilable'=>['required','string'],
            'start_time'=>['required'],
            'end_time'=>['required']
        ]);
        // create data Appointment

        $Appointment= new freetimes_time();
        $Appointment->expert_id=auth()->user()->id;
        $Appointment->Days_u_Avilable=$request->Days_u_Avilable;
        $Appointment->start_time=$request->start_time;
        $Appointment->end_time=$request->end_time;

        //save
        $Appointment->save();

        return response()->json([
            'message'=>'Appointment created Succssefuly',
            'data of Counseling'=>$Appointment,
            'stauts'=>1,
        ]);
    }
}
